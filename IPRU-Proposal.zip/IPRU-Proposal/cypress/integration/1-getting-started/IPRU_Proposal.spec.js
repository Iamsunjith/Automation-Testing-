/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe("Quote Creation For Protection", () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    cy.visit("https://uat.bancaedge.com");
  });

  it.only("IPRU, Risk Profile 1,  PT 10-15, PPT 10-15, Annual with 50,000 Premium", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("84719");
    // Adding Password
    cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    // Enter the CIF
    cy.get('input[formcontrolname="inputNumber"]').type("3136239");
    cy.get("div.search-div > button").should("be.enabled");
    cy.get("div.search-div > button").click();
    cy.contains("Basic Information").should("exist");
    // Click on Quick Quote
    cy.contains("Quick Quote").click();
    cy.contains("Endowment/Money Back").parent().siblings().click();

    cy.get(
      ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
    )
      .wait(2000)
      .click();

    cy.get(
      ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
    ).click();
    // You can invest Rs:
    cy.get('input[formcontrolname="investrate"]').type("50000");
    // You can pay Premiums
    cy.get(
      ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
    ).click();
    // Investment Goals
    cy.get("mat-select[formControlName=investmentGoal]")
      .click()
      .get("mat-option")
      .contains("Savings")
      .click()
      .wait(1000);
    // Are you an NRI
    cy.get(
      "mat-radio-group[formControlName=nri] > :nth-child(2) > mat-radio-button > label"
    ).click();
    // Approximate number of years you want to reach the goal in
    cy.get("mat-select[formControlName=approxYear]")
      .click()
      .get("mat-option")
      .contains("> 25")
      .click();
    // I want to pay Premium for
    cy.get("mat-select[formControlName=payPremiumFor]")
      .click()
      .get("mat-option")
      .contains("5-9")
      .click();
    // cy.get(
    //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
    // ).click();
    cy.get("button.generate-quote-btn")
      .should("be.enabled")
      .click()
      .wait(60000);

    cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
    // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

    // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
    // cy.get("button").get(".btn-div").contains("Show all").click();
    cy.get("app-display-result-life-quote")
      .children(":nth-child(1) ")
      .children(":nth-child(5) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .contains("Buy Now")
      .click();

    cy.get(
      ":nth-child(1) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();

    cy.get("#mat-input-6").type("lastName");
    cy.get(
      ":nth-child(6) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix"
    )
      .click()
      .get("mat-option")
      .contains("Single")
      .click();
    cy.get(".text-align-right > .mat-focus-indicator").click();

    cy.get("#mat-input-11").type("HJKLK5090K");
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    cy.get(
      'app-add-on-covers.ng-star-inserted > .mat-card > .mat-card-content > [fxlayout="row wrap"] > div > .ng-star-inserted'
    )
      .click()
      .wait(2000);
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .mat-focus-indicator"
    ).click();
    cy.get(
      ":nth-child(1) > .cdk-column-Actions > .padding-left > .mat-focus-indicator > .mat-button-wrapper > .mat-icon"
    ).click();
    cy.get(".mat-menu-content > :nth-child(2) > span").click().wait(3000);
    cy.contains("YOUR APPLICATION NUMBER IS");
  });
});

/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe("Quote Creation For Protection", () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    cy.visit("https://uat.bancaedge.com");
  });

  it("Protection, PT 10, PPT 5 ", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("84719");
    // Adding Password
    cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    // Enter the CIF
    cy.get('input[formcontrolname="inputNumber"]').type("3136239");
    cy.get("div.search-div > button").should("be.enabled");
    cy.get("div.search-div > button").click();
    cy.contains("Basic Information").should("exist");
    // Click on Quick Quote
    cy.contains("Quick Quote").click();
    // Selecting Protection
    cy.contains("Protection").parent().siblings().click();
    // Does the Insured smoke/chew tobacco?
    // :nth-child(2) [before the mat-radio-button]is for NO, If you change this to 1 Yes will be selected
    cy.get(
      ".life-protection-form :nth-child(5) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
    ).click();
    // Do you want to add your spouse?
    cy.get(
      ".life-protection-form :nth-child(7) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
    ).click();
    // What is your annual Income ?
    cy.get('input[formcontrolname="annualIncome"]').type("1000000");
    // How would you like to pay your premium?
    // 1 Regular, 2 Limited, 3 Single. In the below we have selected :nth-child(2) as 2
    cy.get(
      ".life-protection-form :nth-child(14) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
    ).click();
    // You can pay Premiums
    // 1 Annual, 2, SemiAnual, 3 Quaterly, 4 Monthly
    cy.get(
      ".life-protection-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
    ).click();
    // You will pay premiums for years?
    cy.get('input[formcontrolname="paypremiumYear"]').type("10");
    // Are you an NRI
    cy.get(
      ".life-protection-form :nth-child(19) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
    ).click();
    cy.get("button.generate-quote-btn")
      .should("be.enabled")
      .click()
      .wait(20000);
    // cy.get("div.plan-quote-col").should("exist");
    // cy.get("button").get(".btn-div").contains("Buy Now").click();
    cy.contains("Total Protect Plus- Lumpsum");
  });
});

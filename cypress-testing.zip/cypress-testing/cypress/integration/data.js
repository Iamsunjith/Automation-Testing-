/// <reference types="cypress" />
let allProducts = [];
let expectedProducts = [];
let Objquote = [];
let expectedNumQuotes;
let rowsLength;
let plansNotFound = [];

describe("Quote Creation For Endownment", () => {
  beforeEach(() => {
    cy.task("readXlsx", {
      file: "cypress/fixtures/TestScenario.xlsx",
      sheet: "Sheet1",
    }).then((rows) => {
      rowsLength = rows.rowsLength;
      cy.writeFile("cypress/fixtures/xlsxData.json", { rows });
    });
    cy.fixture("xlsxData").then(function (data) {
      allProducts = data;
      console.log("ALL PRODUCTS", allProducts);
    });
    cy.visit("https://uat.bancaedge.com");
  });

  // Risk 1
  // Life, Risk Profile 1,  PT 10-15, PPT 5-9, Annual with 50,000 Premium
  it("Life, Risk Profile 1,  PT 10-15, PPT 5-9, Annual with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3566464");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Annual";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 1;

      cy.wrap(allProducts.rows).each((product) => {
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];

      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);
    });
  });

  it("Life, Risk Profile 1,  PT 10-15, PPT 5-9, Half Yearly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3566464");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Half Yearly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 1;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });

  it("Life, Risk Profile 1,  PT 10-15, PPT 5-9, Quarterly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3566464");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(3) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Quarterly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 1;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });

  it("Life, Risk Profile 1,  PT 10-15, PPT 5-9, Monthly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3566464");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(4) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Monthly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 1;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });

  // Life, Risk Profile 1,  PT 10-15, PPT 5-9, Annual with 50,000 Premium

  // Risk 2
  it.only("Life, Risk Profile 2,  PT 10-15, PPT 5-9, Annual with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Annual";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            // console.error("This is an Error");

            console.log("not found plans", plan);
            // Promise.reject(
            //   new Error("Unhandled promise rejection from the spec")
            // );
            // throw new Error("Test Fails Here");
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
          // if (plansNotFound.length !== -1) {
          //   throw new SyntaxError("Test Case Failed");
          // }
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
          // cy.log("PRODUCTS NOT FOUND");
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.wrap(plansNotFound).each((plan) => {
      //   cy.log("PRINTING PLANS HAHAHAHAHH", plan);
      //   console.log("PRINTING PLANS HAHAHAHAHH", plan);
      // });

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);

      // Fail Test Case
      // cy.stub(console, "error").as("consoleError");
    });
  });

  it("Life, Risk Profile 2,  PT 10-15, PPT 5-9, Quarterly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(3) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Quarterly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });

  it("Life, Risk Profile 2,  PT 10-15, PPT 5-9, Half Yearly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Half Yearly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });
  it("Life, Risk Profile 2,  PT 10-15, PPT 5-9, Monthly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(4) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Monthly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });

  // Risk 3
  it("Life, Risk Profile 3,  PT 10-15, PPT 5-9, Annual with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3565584");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Annual";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 3;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });
  it("Life, Risk Profile 3,  PT 10-15, PPT 5-9, Half Yearly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3565584");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Half Yearly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 3;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(4000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });
  it("Life, Risk Profile 3,  PT 10-15, PPT 5-9, Quarterly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3565584");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(3) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Quarterly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 3;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(6000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(8000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });
  it("Life, Risk Profile 3,  PT 10-15, PPT 5-9, Monthly with 50,000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      // cy.visit("http://localhost:4200");
      // cy.visit("https://uat.bancaedge.com");
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3565584");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Endowment/Money Back").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      cy.get('input[formcontrolname="investrate"]').type("50000");
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(4) > mat-radio-button > label"
      ).click();
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click();
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Monthly";
      const premium = 50000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 3;

      cy.wrap(allProducts.rows).each((product) => {
        // console.log("Individual Product Before Filter", product);
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
        ) {
          expectedProducts.push(product);
        }
      });

      // cy.contains("Show all").click();
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];
      // let planNames = [];
      // let ppts = [];
      // let pts = [];
      // // ICICI Products to Exists

      // cy.log("Checking Total Number of Expected Products");
      // cy.get(".plan-name").each((product, index) => {
      //   // console.log("PRINTING PLAN NAME PRODUCT", product);
      //   planNames.push(product.text());
      //   // if (index === 88) {
      //   //   console.log(planNames);
      //   //   console.log("expected", expectedProducts);
      //   // }
      // });
      // cy.get(".pt").each((pt, index) => {
      //   // cy.log(pt.text());
      //   pts.push(pt.text());
      // });
      // cy.get(".ppt").each((ppt, index) => {
      //   // cy.log(ppt.text());
      //   ppts.push(ppt.text());
      // });

      // cy.wrap(planNames).each((planName, i, array) => {
      //   // cy.log(name);
      //   const obj = {
      //     planName,
      //     pt: parseInt(pts[i].split(" ")[0]),
      //     ppt: parseInt(ppts[i].split(" ")[0]),
      //   };
      //   plans.push(obj);
      // });
      // // cy.writeFile("products.txt", plans);
      // const plansNotFound = [];
      // cy.wrap(expectedProducts).each((plan) => {
      //   const planIndex = plans.findIndex((eachPlan) => {
      //     return (
      //       plan["Product"] === eachPlan.planName.trim() &&
      //       plan["PT"] === eachPlan.pt &&
      //       plan["PPT"] === eachPlan.ppt
      //     );
      //   });
      //   if (planIndex === -1) {
      //     plansNotFound.push(plan);
      //   }
      // });
      // cy.wrap(plansNotFound).each((plan, index) => {
      //   console.log("not found plans", plansNotFound);

      //   cy.log(
      //     `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   );

      //   // cy.writeFile(
      //   //   "cypress/fixtures/plansNotFound.txt",
      //   //   `Expecting ${plan.Product} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
      //   // );
      // });
      // .wait(30000);
      cy.url().should("include", "quote-life-insurance");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-life-insurance/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          // Objquote.forEach((quote) => {
          //   // cy.log("INDIVIDUAL QUOTE", quote);
          //   // console.log("INDIVIDUAL QUOTE", quote);
          // });

          Objquote.forEach((quote) => {
            // console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            // console.log(
            //   "PRINT Expected Individual PLAN =======================",
            //   plan
            // );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
            // cy.writeFile(
            //   "cypress/fixtures/plansNotFound.txt",
            //   `Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found`
            // );
          });
        });
      });
      cy.wait(6000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(12000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      // Object.values(Objquote).forEach((quote) => {
      //   console.log("PRING QUOTE", Objquote);
      // });

      // cy.log(expectedProducts.length);

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);

      // cy.get(".plan-name").should("have.length", 104);
      // should("have.length", 104);

      // cy.wrap(expectedNumQuotes).should("have.length", expectedProducts);

      // expect(expectedNumQuotes).to.deep.eq(expectedProducts);
    });
  });
});

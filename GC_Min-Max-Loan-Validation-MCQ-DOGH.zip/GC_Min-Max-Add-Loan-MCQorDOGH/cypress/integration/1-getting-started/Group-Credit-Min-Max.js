/// <reference types="cypress" />

describe("", () => {
  beforeEach(() => {
    cy.visit("https://uat.bancaedge.com");
  });

  // LAP
  // 1
  it("Should add a LAP and expect Recommended Insurance to Fail || Amount: 100000 || Tenure: 2years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("6040718243900");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    cy.get('input[formcontrolname="totalLoanAmount"]').type("100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    cy.contains("No Insurance Products available for Loan").should(
      "be.visible"
    );
  });
  // 2
  it("Should add a LAP and expect DOGH || Amount: 5400000 || Tenure: 15 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182443");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2037")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-calendar > :nth-child(2)  ")
      .get("mat-multi-year-view > :nth-child(1)")
      .contains("2037")
      .click()
      .get("mat-calendar")
      .contains("APR")
      .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 3
  it("Should add a LAP and expect DOGH || Amount: 5500000 || Tenure: 12 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182444");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2037")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-calendar > :nth-child(2)  ")
      .get("mat-multi-year-view > :nth-child(1)")
      .contains("2034")
      .click()
      .get("mat-calendar")
      .contains("APR")
      .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 4
  it("Should add a LAP and expect MCQ || Amount: 5600000 || Tenure: 10 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("6040718244");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2032")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 5
  it("Should add a LAP and expect MCQ || Amount: 20000000 || Tenure: 9 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("604071824377");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2031")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 6
  it("Should add a LAP and expect MCQ || Amount: 20010000 || Tenure: 7 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("604071824810");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20010000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 7
  it("Should add a LAP and expect DOGH || Amount: 3900000 || Tenure: 4 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182334");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 8
  it("Should add a LAP and expect DOGH || Amount: 4000000 || Tenure: 2 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182336");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 9
  it("Should add a LAP and expect MCQ || Amount: 4100000 || Tenure: 6 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182346");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 10
  it("Should add a LAP and expect MCQ || Amount: 20000000 || Tenure: 8 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182347");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2030")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 11 : FAIL
  it("Should add a LAP and expect MCQ || Amount: 20010000 || Tenure: 13 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182348");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20010000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2035")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 12
  it("Should add a LAP and expect DOGH || Amount: 2400000 || Tenure: 14 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182400");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2036")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 14
  it("Should add a LAP and expect MCQ || Amount: 2600000 || Tenure: 3 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182305");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 15
  it("Should add a LAP and expect MCQ || Amount: 12400000 || Tenure: 5 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182306");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 16
  it("Should add a LAP and expect MCQ || Amount: 12500000 || Tenure: 11 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182307");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2033")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 17 : FAIL
  it("Should add a LAP and expect MCQ || Amount: 12600000 || Tenure: 12 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182308");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2034")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 18
  it("Should add a LAP and expect DOGH || Amount: 900000 || Tenure: 10 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182700");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2032")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 19
  it("Should add a LAP and expect DOGH || Amount: 1000000 || Tenure: 9 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182701");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2031")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 20
  it("Should add a LAP and expect MCQ || Amount: 1100000 || Tenure: 7 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182610");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 21
  it("Should add a LAP and expect MCQ || Amount: 4900000 || Tenure: 4 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182611");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 22
  it("Should add a LAP and expect MCQ || Amount: 5000000 || Tenure: 2 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182612");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 23
  it("Should add a LAP and expect MCQ || Amount: 5100000 || Tenure: 6 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182613");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 24
  it("Should add a LAP and expect DOGH || Amount: 400000 || Tenure: 8 years || CIF: 10016907642", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60407182722");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2031")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10016907642");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 25 : FAIL
  it("Should add a LAP and expect DOGH || Amount: 500000 || Tenure: 13 years || CIF: 10050404352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("604071889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2035")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10050404352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 26
  it("Should add a LAP and expect MCQ || Amount: 600000 || Tenure: 14 years || CIF: 10050404352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("60417182898");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2036")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10050404352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 27
  it("Should add a LAP and expect MCQ || Amount: 1900000 || Tenure: 15 years || CIF: 10050404352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61417181827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2036")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10050404352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 28
  it("Should add a LAP and expect MCQ || Amount: 2000000 || Tenure: 3 years || CIF: 10050404352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61417181877");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2036")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10050404352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 29 : FAIL
  it("Should add a LAP and expect MCQ || Amount: 2100000 || Tenure: 5 years || CIF: 10050404352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61417881677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2030")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10050404352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // Education
  // 30
  it("Should add a Education Loan  and expect DOGH || Amount: 100000 || Tenure: 2 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("604061887205");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Education Loan ")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    // Moratorium Period
    cy.get("mat-select[formControlName=moratoriumPeriod]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("12 Months")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 31
  it("Should add a Education Loan  and expect DOGH || Amount: 5400000 || Tenure: 20 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("603060887505");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Education Loan ")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2042")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    // Moratorium Period
    cy.get("mat-select[formControlName=moratoriumPeriod]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("12 Months")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 32
  it("Should add a Education Loan  and expect DOGH || Amount: 5500000 || Tenure: 3 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("603069887240");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Education Loan ")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2042")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    // Moratorium Period
    cy.get("mat-select[formControlName=moratoriumPeriod]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("12 Months")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 33 : FAIL
  it("Should add a LAP and expect MCQ || Amount: 5600000 || Tenure: 17 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("651157182898");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Education Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2042")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    // Moratorium Period
    cy.get("mat-select[formControlName=moratoriumPeriod]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("12 Months")
      .click();
    cy.contains("Select Customer").click();

    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 34
  it("Should add a LAP and expect MCQ || Amount: 7400000 || Tenure: 15 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("651267182898");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Education Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2037")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    // Moratorium Period
    cy.get("mat-select[formControlName=moratoriumPeriod]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("12 Months")
      .click();
    cy.contains("Select Customer").click();

    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 60 ========= Education

  // Car Loan
  // 61
  it("Should add a Car Loan  and expect DOGH || Amount: 100000 || Tenure: 2 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("6096859889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 62
  it("Should add a Car Loan  and expect DOGH || Amount: 5400000 || Tenure: 7 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605862889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 63
  it("Should add a Car Loan  and expect DOGH || Amount: 5500000 || Tenure: 3 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605815889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 64
  it("Should add a Car Loan and expect MCQ || Amount: 5600000 || Tenure: 5 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61419891677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan ")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 65
  it("Should add a Car Loan and expect MCQ || Amount: 7400000 || Tenure: 2 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61419771677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 66
  it("Should add a Car Loanand expect MCQ || Amount: 7500000 || Tenure: 6 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61419071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 67 : FAIL
  it("Should add a Car Loan and expect MCQ || Amount: 7600000 || Tenure: 3 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61419671677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 68
  it("Should add a Car Loan  and expect DOGH || Amount: 3900000 || Tenure: 5 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("635815889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 69
  it("Should add a Car Loan  and expect DOGH || Amount: 4000000 || Tenure: 4 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("645815889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 70
  it("Should add a Car Loanand expect MCQ || Amount: 4100000 || Tenure: 6 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69419071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 71
  it("Should add a Car Loanand expect MCQ || Amount: 7400000 || Tenure: 5 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("64819071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 72
  it("Should add a Car Loanand expect MCQ || Amount: 7500000 || Tenure: 2 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("67819071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 73 : FAIL
  it("Should add a Car Loanand expect MCQ || Amount: 7600000 || Tenure: 6 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("66819071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 74
  it("Should add a Car Loan  and expect DOGH || Amount: 2400000 || Tenure: 5 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("615815889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 75
  it("Should add a Car Loan  and expect DOGH || Amount: 2500000 || Tenure: 7 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("625815889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 76
  it("Should add a Car Loanand expect MCQ || Amount: 2600000 || Tenure: 6 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69819071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 77
  it("Should add a Car Loanand expect MCQ || Amount: 3900000 || Tenure: 2 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69817071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 78
  it("Should add a Car Loanand expect MCQ || Amount: 4000000 || Tenure: 5 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69857071677");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 79 : FAIL
  it("Should add a Car Loanand expect MCQ || Amount: 4100000 || Tenure: 3 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69857071777");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 80
  it("Should add a Car Loan  and expect DOGH || Amount: 900000 || Tenure: 2 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("625815779775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 81
  it("Should add a Car Loan  and expect DOGH || Amount: 1000000 || Tenure: 4 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("625815979775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ========================== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 82
  it("Should add a Car Loanand expect MCQ || Amount: 1100000 || Tenure: 3 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69857071767");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 83
  it("Should add a Car Loanand expect MCQ || Amount: 1400000 || Tenure: 5 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69857071067");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 84
  it("Should add a Car Loanand expect MCQ || Amount: 1500000 || Tenure: 7 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69857071367");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Year : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 85 : FAIL
  it("Should add a Car Loanand expect MCQ || Amount: 1600000 || Tenure: 2 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69867071367");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Year : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // Home Loan
  // 86 : FAIL
  it("Should add a Home Loan and expect DOGH || Amount: 100000 || Tenure: 2 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61851889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 87
  it("Should add a Home Loan and expect DOGH || Amount: 5400000 || Tenure: 30 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61850889675");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2052")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======== CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 88
  it("Should add a Home Loan and expect DOGH || Amount: 5500000 || Tenure: 3 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61862889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 89
  it("Should add a Home Loan and expect MCQ || Amount: 5600000 || Tenure: 4 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("614852881687");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 90
  it("Should add a Home Loan and expect MCQ || Amount: 19000000 || Tenure: 9 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("610892551697");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("19000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2031")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 91
  it("Should add a Home Loan and expect MCQ || Amount: 20000000 || Tenure: 5 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("614052551687");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 92 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 20010000 || Tenure: 11 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("614052552687");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20010000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2033")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 93
  it("Should add a Home Loan and expect DOGH || Amount: 3900000 || Tenure: 12 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61862889670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Year : Tenure
      .contains("2034")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 94
  it("Should add a Home Loan and expect DOGH || Amount: 4000000 || Tenure: 6 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61000989670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Year : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      // .get("mat-calendar > :nth-child(2)  ")
      // .get("mat-multi-year-view > :nth-child(1)")
      // .contains("2034")
      // .click()
      // .get("mat-calendar")
      // .contains("APR")
      // .click()
      // Date
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 95
  it("Should add a Home Loan and expect MCQ || Amount: 4100000 || Tenure: 14 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("694057552687");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2036")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 96
  it("Should add a Home Loan and expect MCQ || Amount: 19000000 || Tenure: 16 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("694956452687");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("19000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2038")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 97
  it("Should add a Home Loan and expect MCQ || Amount: 20000000 || Tenure: 7 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("694956452387");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 98 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 20010000 || Tenure: 17 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("694056452387");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("20010000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2039")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 99
  it("Should add a Home Loan and expect DOGH || Amount: 2400000 || Tenure: 15 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61090989670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2037")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 100
  it("Should add a Home Loan and expect DOGH || Amount: 2500000 || Tenure: 18 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61190989670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2040")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 101
  it("Should add a Home Loan and expect MCQ || Amount: 2600000 || Tenure: 8 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("694059952387");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2030")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 102 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 12400000 || Tenure: 25 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("697059952387");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2047")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 103
  it("Should add a Home Loan and expect MCQ || Amount: 12500000 || Tenure: 20 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("697959952387");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2042")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 104 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 12600000 || Tenure: 10 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("697950952381");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("12600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2032")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 105 : FAIL
  it("Should add a Home Loan and expect DOGH || Amount: 400000 || Tenure: 19 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("61190019670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2041")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 106 : FAIL
  it("Should add a Home Loan and expect DOGH || Amount: 500000 || Tenure: 13 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("64490019670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2035")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 107 : FAIL
  it("Should add a Home Loan and expect DOGH || Amount: 600000 || Tenure: 21 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("64492219670");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2043")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF ============================ CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });

  // 108 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 1900000 || Tenure: 28 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("64895232381");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2050")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 109
  it("Should add a Home Loan and expect MCQ || Amount: 2000000 || Tenure: 22 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("69395230381");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2044")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // 110 : FAIL
  it("Should add a Home Loan and expect MCQ || Amount: 2100000 || Tenure: 29 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("64495230381");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get(
        "mat-calendar > :nth-child(1) > :nth-child(1) > :nth-child(1) > :nth-child(4)"
      )
      .click()
      .get("mat-multi-year-view")
      // Years : Tenure
      .contains("2051")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });

  // Personal/Business Loan
  // 111
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 100000 || Tenure: 2 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("604183889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 112
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 5400000 || Tenure: 7 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605583889775");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 113
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 5500000 || Tenure: 6 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605583889975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 114
  it("Should add a Personal/Business and expect MCQ || Amount: 5600000 || Tenure: 5 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("601225711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 115
  it("Should add a Personal/Business and expect MCQ || Amount: 7400000 || Tenure: 3 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("616225711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 116
  it("Should add a Personal/Business and expect MCQ || Amount: 7500000 || Tenure: 6 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676225711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 117 : FAIL
  it("Should add a Personal/Business and expect MCQ || Amount: 7600000 || Tenure: 4 years || CIF: 10047017416", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676765711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10047017416");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 118
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 3900000 || Tenure: 2 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605983889975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 119
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 4000000 || Tenure: 7 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605653889975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 120
  it("Should add a Personal/Business and expect MCQ || Amount: 4100000 || Tenure: 5 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676885711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 121
  it("Should add a Personal/Business and expect MCQ || Amount: 7400000 || Tenure: 6 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676115711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 122
  it("Should add a Personal/Business and expect MCQ || Amount: 7500000 || Tenure: 2 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676915711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 123 : FAIL
  it("Should add a Personal/Business and expect MCQ || Amount: 7600000 || Tenure: 5 years || CIF: 15000750779", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676974711827");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("7600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("15000750779");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 124
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 2400000 || Tenure: 3 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605653019975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 125
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 2500000 || Tenure: 4 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605658119975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("2500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 126 : FAIL
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 26000000 || Tenure: 5 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("605838119975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("26000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 127
  it("Should add a Personal/Business and expect MCQ || Amount: 3900000 || Tenure: 2 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676915711737");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("3900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 128
  it("Should add a Personal/Business and expect MCQ || Amount: 4000000 || Tenure: 5 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676925711797");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2027")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 129 : FAIL
  it("Should add a Personal/Business and expect MCQ || Amount: 4100000 || Tenure: 6 years || CIF: 10035676451", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("678425711797");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("4100000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10035676451");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 130
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 900000 || Tenure: 4 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("638658119975");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("900000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 131
  it("Should add a Personal/Business Loan and expect DOGH || Amount: 1000000 || Tenure: 7 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("638658119954");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2029")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();
    cy.contains("Select Customer").click();
    // CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Declaration of Good Health").should("be.visible");
  });
  // 132
  it("Should add a Personal/Business and expect MCQ || Amount: 1200000 || Tenure: 4 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676925711755");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1200000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2026")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 133
  it("Should add a Personal/Business and expect MCQ || Amount: 1400000 || Tenure: 3 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676925711766");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1400000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2025")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 134
  it("Should add a Personal/Business and expect MCQ || Amount: 1500000 || Tenure: 6 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676925711733");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1500000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2028")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
  // 135 : FAIL
  it("Should add a Personal/Business and expect MCQ || Amount: 1600000 || Tenure: 2 years || CIF: 10051444352", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    //   Adding Loan account Number
    cy.get('input[formcontrolname="loanAccouontNo"]').type("676925711743");
    // Loan Type
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Personal and Business Loan")
      .click();
    // Loan Amount
    cy.get('input[formcontrolname="totalLoanAmount"]').type("1600000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");
    // Start Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    // End Date
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2024")
      .click()
      .get("mat-calendar > :nth-child(2)")
      // Years : Tenure
      .contains("2024")
      .click()
      .get("mat-calendar")
      // Month
      .contains("APR")
      .click()
      .get("mat-month-view")
      .contains("6")
      .click();

    cy.contains("Select Customer").click();
    // CIF ======================CIF
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10051444352");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    // CheckBox
    cy.get(".mat-checkbox-inner-container").click();
    // Save
    cy.contains("Save Details").click().wait(1000);
    //
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();

    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-22").type("6");
    // Height in Inches
    cy.get("#mat-input-23").type("10");
    // Weight
    cy.get("#mat-input-24").type("70");
    // Nationality
    cy.get(
      "#mat-select-6 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-7 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-8 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-9 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-25").type("Sunjith");
    // Last Name

    cy.get("#mat-input-26").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();
    cy.contains("Life Style Details").should("be.visible");
    cy.contains("Family Details").should("be.visible");
  });
});

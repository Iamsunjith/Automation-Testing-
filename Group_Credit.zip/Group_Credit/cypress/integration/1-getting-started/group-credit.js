/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe("Quote Creation For Protection", () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    cy.visit("https://uat.bancaedge.com");
  });

  it("Should add a car Loan and expect Recommended Insurance", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    cy.get('input[formcontrolname="loanAccouontNo"]').type("56465528498789");
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Car Loan")
      .click();
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();

    cy.contains("Select Customer").click();
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10017031094");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
  });

  it("Should add a car Loan and expect Recommended Insurance", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    cy.get('input[formcontrolname="loanAccouontNo"]').type("564657686844");
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Home Loan")
      .click();
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("7")
      .click();

    cy.contains("Select Customer").click();
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10017031094");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
  });

  it("Should add LAP with 1 Lakh and expect Recommended Insurance", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.contains("Add Loan Details").should("exist").click().wait(3000);
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(1) mat-form-field"
    );
    cy.get("mat-select[formControlName=branchCode]")
      .click()
      .wait(2000)
      .get("mat-option")
      .contains("Head Office")
      .click();
    cy.get('input[formcontrolname="loanAccouontNo"]').type("16495752132355");
    cy.get("mat-select[formControlName=loanType]")
      .click()
      .get("mat-option")
      .contains("Loan Against Property")
      .click();
    cy.get('input[formcontrolname="totalLoanAmount"]').type("5000000");
    // cy.get('input[formcontrolname="loanStartDate"]').get("button");

    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(5) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("24")
      .click();
    cy.get(
      "form :nth-child(1) > mat-card > mat-card-content :nth-child(6) mat-form-field :nth-child(1) :nth-child(1) :nth-child(2) > mat-datepicker-toggle"
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-month-view")
      .contains("23")
      .click();

    cy.contains("Select Customer").click();
    cy.get(
      "form :nth-child(1) :nth-child(1) :nth-child(1) :nth-child(3) > input"
    ).type("10003915240");
    cy.contains("Submit").click().wait(3000);
    cy.get("mat-dialog-container ").contains("Select Customer").click();
    cy.get("mat-select[formControlName=primaryBorrowerTitle]")
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    cy.contains("Add").click();
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click();
    cy.contains("Next").click();
    cy.get(
      '#cdk-step-content-0-1 > app-genral.ng-star-inserted > [_ngcontent-gjv-c335=""][novalidate=""] > :nth-child(1) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(1) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix'
    ).click();
  });

  it.only("Should Send to UW as Declaration of GH is Yes for : Have you had any loss or gain in weight of 5 Kgs or more in last 6 months?", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("56465528498789")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();

    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mr.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("MAR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(1) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Brother")
      .click();

    // Declaration of Good Health================================================================================================

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Have you had any loss or gain in weight of 5 Kgs or more in last 6 months?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(".mat-card-content > :nth-child(2) > .mat-radio-group  ")
      .contains("Yes")
      .click()
      .wait(1000);
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(2) :nth-child(4) > mat-form-field > :nth-child(1) :nth-child(1) :nth-child(1) > input"
      )
      .type("Yes, Lost 10 Kg");
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(4) > .mat-radio-group > :nth-child(2) > .mat-radio-button "
      )
      .contains("No")
      .click();

    //  Are you currently engaged in hazardous sports/activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(6) > .mat-radio-group > :nth-child(2) > .mat-radio-button"
      )
      .contains("No")
      .click();
    // Have you ever been diagnosed with or received treatment for any disability or medical condition such as but not limited to high cholesterol, high blood pressure, chest pain, heart attack or any other heart condition; stroke, transient ischemic attack or any other cerebrovascular disease; diabetes or any other endocrinal disease; kidney disease; HIV / AIDS or AIDS related complex; any cancer or tumor; Asthma or any other respiratory disease; Any mental or nervous disease; Hepatitis or any other liver disease; Blood disorders; Digestive and bowel disorders; paraplegia or any other disorder of the bones, spine or muscle?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(8) > .mat-radio-group > :nth-child(2) > .mat-radio-button"
      )
      .contains("No")
      .click();
    // Apart from minor ailments, such as cold and flu, have you received any treatment from or consulted with any doctor or specialist or been hospitalized or undergone hospital treatment or investigations (excluding routine health checkups) in last 5 years or Have you been absent from work on health grounds for more than 10 days at a stretch during the last 12 months?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(10) > .mat-radio-group > :nth-child(2) > .mat-radio-button"
      )
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?or Have you been absent from work on health grounds for more than 10 days at a stretch during the last 12 months?
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(12) > .mat-radio-group > :nth-child(2) > .mat-radio-button"
      )
      .contains("No")
      .click();
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.get("@newcontainer")
      .get("app-medical-section > :nth-child(1)")
      .get(
        ".mat-card-content > :nth-child(14) > .mat-radio-group > :nth-child(2) > .mat-radio-button"
      )
      .contains("No")
      .click();

    // COVID FORM
    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();
    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();
    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();
    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();
    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();
    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    //AddressLine 1
    cy.get("#mat-input-25").type("adsasdasdads");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // The Below Filds are auto added based on the Pincode
    // City
    // cy.get("#mat-input-27").type("Pune");
    // State
    // cy.get("#mat-input-28").type("Maharashtra");
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get("#cdk-step-content-0-3 > .text-align-right > .next-btn").click();
    cy.contains(
      "The Proposal has been sent to Customer for Review and Payment"
    ).should("be.visible");
  });
});

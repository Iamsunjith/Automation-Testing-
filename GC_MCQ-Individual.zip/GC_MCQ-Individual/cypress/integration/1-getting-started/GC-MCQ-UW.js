/// <reference types="cypress" />

// Welcome to Cypress!
//
// This spec file contains a variety of sample tests
// for a todo list app that are designed to demonstrate
// the power of writing tests in Cypress.
//
// To learn more about how Cypress works and
// what makes it such an awesome testing tool,
// please read our getting started guide:
// https://on.cypress.io/introduction-to-cypress

describe("example to-do app", () => {
  beforeEach(() => {
    // Cypress starts out with a blank slate for each test
    // so we must tell it to visit our website with the `cy.visit()` command.
    // Since we want to visit the same URL at the start of all our tests,
    // we include it in our beforeEach function so that it runs before each test
    cy.visit("https://uat.bancaedge.com");
  });
  // Are you Pregnant? If yes, How many months
  it.only("Should Send to UW Review, For Female Life only: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      .children(":nth-child(2)")
      .children(":nth-child(4)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("4 Months");

    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-25").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Has the life to be insured had any abortion or miscarriage or caesarian section
  it("Should Send to UW Review, For Female Life only: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // cy.contains("For Female Life only")
    //   .parent()
    //   .parent()
    //   .siblings()
    //   .children(":nth-child(2) ")
    //   .contains("Yes")
    //   .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("Yes")
      .click();
    // Yes
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      .children(":nth-child(4)")
      .children(":nth-child(4)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("Yes, miscarriage ");

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-25").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Life Style Details
  // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
  it("Should Send to UW Review, Life Style Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      .children(":nth-child(2)")
      .children(":nth-child(4)")
      .contains("Fill Details")
      .click();
    // Frequency
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("Medium");
    // Quality
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("10");
    // No of Years
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(3)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("5");
    // Save
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(3)")
      .children(":nth-child(2)")
      .contains("Save")
      .click();
    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // Alcohol / Hard liquor/ Wine / Beer
  it("Should Send to UW Review, Life Style Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      .children(":nth-child(4)")
      .children(":nth-child(4)")
      .contains("Fill Details")
      .click();
    // Frequency
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("Medium");
    // Quality
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("10");
    // No of Years
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(3)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("5");
    // Save
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(3)")
      .children(":nth-child(2)")
      .contains("Save")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
  it("Should Send to UW Review, Life Style Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      .children(":nth-child(6)")
      .children(":nth-child(4)")
      .contains("Fill Details")
      .click();
    // Frequency
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("Medium");
    // Quality
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("10");
    // No of Years
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(2)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(3)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("5");
    // Save
    cy.contains("Editing Details of SWEETY RATNER")
      .parent()
      .children(":nth-child(3)")
      .children(":nth-child(2)")
      .contains("Save")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // General Details
  // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
  it("Should Send to UW Review, General Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .children(":nth-child(4)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("Mines");

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-25").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc
  it("Should Send to UW Review, General Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .children(":nth-child(4)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("diving");

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-25").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
  it("Should Send to UW Review, General Details: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("Yes")
      .click();

    // Yes
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .children(":nth-child(4)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1)")
      .children(":nth-child(1) > input")
      .type("postponed");

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();
    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-25").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-26").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-27").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-28").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // Medical History
  // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(2) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();
    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(4) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();
    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(6) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(8) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================
    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();
    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(10) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();
    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(12) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(14) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================
    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(16) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================
    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();
    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });

  // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(18) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();
    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("Yes")
      .click();

    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(20) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();
    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Any other illness/impairment/disability not mentioned above?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(22) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();
    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(24) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
  // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
  it("Should Send to UW Review, Medical History: is slected Yes", async () => {
    cy.contains("Login");
    cy.get("div.main-container").should("exist");
    cy.get("div.action > button").should("exist");
    cy.get("input[placeholder='Username']").should("exist");
    // Adding User Name
    cy.get("input[placeholder='Username']").type("bombranchuser");
    // Adding Password
    cy.get("input[placeholder='Password']").type("^4jNrDyi976X");
    cy.get("div.action > button[type='submit']").click();
    cy.contains("Select Customer By").should("exist");
    cy.get("div.search-div > button").should("be.disabled");
    cy.get('[routerlink="/group-credit"] > .mat-button-wrapper').click();
    cy.get(".search-container")
      .then((conatiner) => {
        const body = conatiner.contents().find("div");
        cy.wrap(body).as("container").wait(1000);
      })
      .wait(1000);
    // Adding the Loan Account Number
    cy.get("@container")
      .wait(1000)
      .get("mat-form-field :nth-child(1) :nth-child(1) :nth-child(3) > input")
      .type("60407182346")
      .wait(1000);
    cy.get("@container").wait(1000).get("button").contains("Submit").click();
    // Selecting Recommend Insurance
    cy.contains("Recommended Insurance").click();
    cy.get(".mat-checkbox-inner-container").click();
    cy.contains("Save Details").click().wait(1000);
    // cy.contains("Next").click();
    cy.get(
      "mat-horizontal-stepper > :nth-child(2) > :nth-child(1) > :nth-child(2) > button"
    ).click();
    // Title
    cy.get(
      "#mat-select-1 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // Height in Feet
    cy.get("#mat-input-11").type("6");
    // Height in Inches
    cy.get("#mat-input-12").type("10");
    // Weight
    cy.get("#mat-input-13").type("70");
    // Nationality
    cy.get(
      "#mat-select-2 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Indian")
      .click();

    // Policy Branch
    cy.get(
      "#mat-select-3 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Head Office")
      .click();

    // Age Proof
    cy.get(
      "#mat-select-4 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .wait(2000)
      .contains("Passport")
      .click();
    // Check Box
    cy.get(".mat-checkbox-inner-container").click();
    // Nominy Details
    // Title
    cy.get(
      "#mat-select-5 > .mat-select-trigger > .mat-select-value > .mat-select-placeholder"
    )
      .click()
      .get("mat-option")
      .contains("Mrs.")
      .click();
    // First Name
    cy.get("#mat-input-14").type("Sunjith");
    // Last Name

    cy.get("#mat-input-15").type("PS");
    // DOB

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > :nth-child(4) > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-suffix > .mat-datepicker-toggle > .mat-focus-indicator > .mat-button-wrapper > .mat-datepicker-toggle-default-icon'
    )
      .click()
      .get("mat-datepicker-content")
      .get("mat-calendar")
      .get("mat-calendar-header")
      .find("button")
      .contains("APR 2022")
      .click()
      .get("mat-calendar")
      // Year
      .contains("2000")
      .click()
      .get("mat-calendar")
      // Month
      .contains("JAN")
      .click()
      .get("mat-calendar")
      .get("mat-month-view")
      // Date
      .contains("2")
      .click();

    // Gender

    cy.get(
      ':nth-child(3) > .mat-card-content > [fxlayout="row wrap"] > .margin-top-5 > .mat-radio-group > :nth-child(2) > .mat-radio-button'
    ).click();
    // RelationShip
    cy.get(".mat-select-placeholder")
      .click()
      .get("mat-option")
      .contains("Sister")
      .click();

    // For Female Life only

    cy.get(".mat-horizontal-content-container").then((conatiner) => {
      const body = conatiner.contents().find("mat-card");
      cy.wrap(body).as("newcontainer").wait(1000);
    });
    // Are you Pregnant? If yes, How many months
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Has the life to be insured had any abortion or miscarriage or caesarian section
    cy.contains("For Female Life only")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Life Style Details
    // Nicotine containing products like: Tobacco/Bidi/Cigarette/Cigar /Gutkha / Khaini /Pan masala etc...
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Alcohol / Hard liquor/ Wine / Beer
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Drugs like-Cannabis/Marijuana/Ecstasy/LSD/Heroin or any other drug
    cy.contains("Life Style Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Family Details
    // Have the parents / brothers /sisters of life to be insured suffered from or died of heart disease, stroke, high blood pressure, diabetes mellitus, any form of eye disease, cancer, kidney disease or paralysis, or any hereditary/familial disorders? If Yes, kindly give details.
    cy.contains("Family Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // General Details
    // Is your occupation associated with any hazards e.g. chemical factory, mines, explosives, corrosive chemicals, services in armed forces etc?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you currently engaged in any hazardous sports / activities like bungee jumping, diving, parachuting, sky diving, motor racing, boxing etc.
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Has any proposal for insurance on your life ever been declined, postponed, withdrawn or accepted at an increased premium, special terms or with reduced cover?
    cy.contains("General Details")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Medical History
    // High or low blood pressure, raised cholesterol, rheumatic fever, chest pain, heart attack, myocardial Infarction or any other disorder of heart or blood vessels?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Diabetes mellitus, High blood sugar, thyroid or any other glands disorder or any other endocrine disorders or any other disease of the stomach, liver, spleen, gall bladder or pancreas?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Asthma, persistent cough, coughing with blood, pneumonia, bronchitis, pleurisy, tuberculosis or any other respiratory disorder or disorder of lungs?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Stroke, Paralysis, epilepsy, fits, transient ischaemic attack, double vision, weakness of limbs, nervous breakdown, persistent headache or any other disease related to the brain or the nervous system or mental disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Any disease or disorder of ear, nose, eyes or throat, including defective sight or hearing and discharge from ears, chronic gastritis, stomach or ulcer , blood in stools, fistula or any other stomach or intestine or bowel disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Cancer, tumor, cyst or any kind of growth or any congenital disorders?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Blood, protein or sugar in urine, kidney stones, disorder of kidney, prostate, urinary system or reproductive system?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Jaundice, hepatitis B, Anaemia, or any other form of hepatitis, liver disorder or gall bladder disorder?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Has the life to be insured or partner ever been tested positive for HIV and /or hepatitis, including routine testing for insurance or employment?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Leprosy, Gout, arthritis, pain or any physical defect/ deformity /disorders of muscles, spine, limbs/ joints or skin?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Any other illness/impairment/disability not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Has the life to be insured ever consulted doctor/ investigated / hospitalized or undergone any treatment or operation for any ailment/ injury not mentioned above?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Has the Life to be insured remained absent from his / her place of work for more than 7 days on health grounds/ accident/injury or claimed against his/ her health insurance policies in the past 3 years?
    cy.contains("Medical History")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("Yes")
      .click();
    // Yes
    // ==============================
    cy.contains("Medical History")
      .parent()
      .parent()
      .parent()
      .children("mat-card-content")
      // Selection below Dev
      .children(":nth-child(26) ")
      .children(":nth-child(4) ")
      .contains("Fill Details")
      .click();
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasdasd");
    // Date
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // Date
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .click();
    cy.get("mat-calendar").children(":nth-child(2) ").contains("12").click();
    // Radio
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .contains("Yes")
      .click();

    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(2) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      // TextBox
      .children(":nth-child(4) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) ")
      .children(":nth-child(1) > textarea")
      .type("asdasd");
    cy.contains("Editing Details")
      .parent()
      .children(":nth-child(3) ")
      .children(":nth-child(2) ")
      .click();
    // ======================

    // COVID FORM =====================================================================================

    // Are you, or your family have been in close contact in last 3 weeks with anyone who has been quarantined or who has been diagnosed with novel coronavirus (SARS-CoV-2/COVID-19) ? If yes, please provide details.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(2) ")
      .contains("No")
      .click();

    // Are you, or your family have served a notice of quarantine in any form imposed by local health authorities or government or airport authority for possible exposure to novel coronavirus (SARS- CoV2/COVID-19) in last 2 months/8 weeks? If yes, please provide more details like location, dates, quarantine period.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(4) ")
      .contains("No")
      .click();

    // Have you been advised to be tested to rule in, or rule out, a diagnosis of novel coronavirus (SARSCoV-2/COVID-19)? Or, are you awaiting the result of a test which has already been submitted for the novel coronavirus (SARS-CoV-2/COVID-19)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(6) ")
      .contains("No")
      .click();

    // Have you ever tested positive for the novel coronavirus (SARS-CoV-2/COVID-19)? If yes, provide the date of positive diagnosis. And also details of subsequent tests.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(8) ")
      .contains("No")
      .click();

    // Have you experienced any fever symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(10) ")
      .contains("No")
      .click();

    // Have you experienced any Cough symptoms within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(12) ")
      .contains("No")
      .click();

    // Have you experienced Shortness of breath within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(14) ")
      .contains("No")
      .click();

    // Have you experienced Malaise (flu-like tiredness) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(16) ")
      .contains("No")
      .click();

    // Have you experienced Rhinorrhea (mucus discharge from the nose) within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(18) ")
      .contains("No")
      .click();

    // Have you experienced Sore throat within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(20) ")
      .contains("No")
      .click();

    // Have you experienced Gastro-intestinal symptoms such as nausea, vomiting and/or diarrhea within the last 4 weeks?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(22) ")
      .contains("No")
      .click();

    // Are you a Healthcare professionals (Include forinstanceGeneral Practitioners,Doctors, HospitalDoctors, Surgeons, Therapists, Nurses,Pathologist, paramedics, Pharmacist, Ward helpers, Individuals working in Hospitals/ Clinics having novel coronavirus (SARS-CoV-2/COVID-19) Ward ?Please provide details whether working in Hospital with Covid-19 ward or treating orin contact with Covid019 infected individuals.
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(24) ")
      .contains("No")
      .click();

    // Are you currently residing outside of India(Travel Declaration)?"
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(26) ")
      .contains("No")
      .click();

    // Have you travelled abroad in the past 14 days?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(28) ")
      .contains("No")
      .click();

    // Do you intend to travel abroad in next 3 months?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(30) ")
      .contains("No")
      .click();

    // Have you been vaccinated for COVID19(COVID19 Vaccination details)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(32) ")
      .contains("No")
      .click();

    // Have you been admitted to a hospital (or to any other kind of medical or public health institution/unit) while you have/had a COVID-19 infection or whilst you are/were suspected to have a possible COVID-19 infection?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(34) ")
      .contains("No")
      .click();

    // Were you admitted in intensive care (in case of hospitalisation)?
    cy.contains("Covid Form")
      .parent()
      .parent()
      .siblings()
      .children(":nth-child(36) ")
      .contains("No")
      .click();
    // Next
    cy.get("#cdk-step-content-0-1 > .text-align-right > .next-btn").click();
    // Mailing Address
    //AddressLine 1
    cy.get("#mat-input-27").type("MG Road");
    // AddressLine 2
    cy.get("#mat-input-28").type("GANDHI BHAVAN ROAD");
    // AddressLine 3
    cy.get("#mat-input-29").type("KOTHRUD");
    // PinCode
    cy.get("#mat-input-30").type("411038");
    // Next
    cy.get("#cdk-step-content-0-2 > .text-align-right > .next-btn").click();
    // Submit
    cy.get(
      "#cdk-step-content-0-3 > .text-align-right > .next-btn > .mat-button-wrapper"
    ).click();
  });
});

/// <reference types="cypress" />
let allProducts = [];
let expectedProducts = [];
let Objquote = [];
let expectedNumQuotes;
let rowsLength;
let plansNotFound = [];

describe("Quote Creation For Endownment", () => {
  beforeEach(() => {
    cy.task("readXlsx", {
      file: "cypress/fixtures/TestScenario.xlsx",
      sheet: "Sheet1",
    }).then((rows) => {
      rowsLength = rows.rowsLength;
      cy.writeFile("cypress/fixtures/xlsxData.json", { rows });
    });
    cy.fixture("xlsxData").then(function (data) {
      allProducts = data;
      console.log("ALL PRODUCTS", allProducts);
    });
    cy.visit("https://uat.bancaedge.com");
  });

  // Risk 2
  // Life, Risk Profile 1,  PT 10-15, PPT 5-9, Annual with 100000 Premium
  it("IPRU, Risk Profile 1,  PT 10-15, PPT 5-9, Annual with 100000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Saving Unit Linked").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      // You can invest Rs:
      cy.get('input[formcontrolname="investrate"]').type("200000");
      // You can pay Premiums
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      ).click();
      // Investment Goals
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click()
        .wait(1000);
      // Are you an NRI
      cy.get(
        "mat-radio-group[formControlName=nri] > :nth-child(2) > mat-radio-button > label"
      ).click();
      // Approximate number of years you want to reach the goal in
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      // I want to pay Premium for
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Annual";
      const premium = 200000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;
      // const insurer = "ETLI";
      // const insurer = "IPRU";
      // const insurer = insurer;

      cy.wrap(allProducts.rows).each((product) => {
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
          // product["Insurer"] === insurer
        ) {
          expectedProducts.push(product);
        }
      });

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];

      cy.url().should("include", "quote-unit-link");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-unit-link/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          // console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          Objquote.forEach((quote) => {
            console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          console.log("Printing Plans Array", plans);
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            console.log(
              "PRINT Expected Individual PLAN =======================",
              plan
            );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);
    });
  });
  it("IPRU, Risk Profile 1,  PT 10-15, PPT 5-9, Half Yearly with 100000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Saving Unit Linked").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      // You can invest Rs:
      cy.get('input[formcontrolname="investrate"]').type("200000");
      // You can pay Premiums
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      // Investment Goals
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click()
        .wait(1000);
      // Are you an NRI
      cy.get(
        "mat-radio-group[formControlName=nri] > :nth-child(2) > mat-radio-button > label"
      ).click();
      // Approximate number of years you want to reach the goal in
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      // I want to pay Premium for
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Half Yearly";
      const premium = 200000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;
      // const insurer = "ETLI";
      // const insurer = "IPRU";
      // const insurer = insurer;

      cy.wrap(allProducts.rows).each((product) => {
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
          // product["Insurer"] === insurer
        ) {
          expectedProducts.push(product);
        }
      });

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];

      cy.url().should("include", "quote-unit-link");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-unit-link/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          // console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          Objquote.forEach((quote) => {
            console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          console.log("Printing Plans Array", plans);
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            console.log(
              "PRINT Expected Individual PLAN =======================",
              plan
            );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);
    });
  });
  it.only("IPRU, Risk Profile 1,  PT 10-15, PPT 5-9, Monthly with 100000 Premium", async () => {
    cy.fixture("xlsxData").then((data) => {
      cy.contains("Login");
      cy.get("div.main-container").should("exist");
      cy.get("div.action > button").should("exist");
      cy.get("input[placeholder='Username']").should("exist");
      // Adding User Name
      cy.get("input[placeholder='Username']").type("84719");
      // Adding Password
      cy.get("input[placeholder='Password']").type("4rU4zA\\m8FYo");
      cy.get("div.action > button[type='submit']").click();
      cy.contains("Select Customer By").should("exist");
      cy.get("div.search-div > button").should("be.disabled");
      // Enter the CIF
      cy.get('input[formcontrolname="inputNumber"]').type("3136239");
      cy.get("div.search-div > button").should("be.enabled");
      cy.get("div.search-div > button").click();
      cy.contains("Basic Information").should("exist");
      // Click on Quick Quote
      cy.contains("Quick Quote").click();
      cy.contains("Saving Unit Linked").parent().siblings().click();

      cy.get(
        ".savings-traditional-form :nth-child(1) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      )
        .wait(2000)
        .click();

      cy.get(
        ".savings-traditional-form :nth-child(6) > :nth-child(2) > mat-radio-group > :nth-child(2) > mat-radio-button > label"
      ).click();
      // You can invest Rs:
      cy.get('input[formcontrolname="investrate"]').type("200000");
      // You can pay Premiums
      cy.get(
        ".savings-traditional-form :nth-child(9) > :nth-child(2) > mat-radio-group > :nth-child(4) > mat-radio-button > label"
      ).click();
      // Investment Goals
      cy.get("mat-select[formControlName=investmentGoal]")
        .click()
        .get("mat-option")
        .contains("Savings")
        .click()
        .wait(1000);
      // Are you an NRI
      cy.get(
        "mat-radio-group[formControlName=nri] > :nth-child(2) > mat-radio-button > label"
      ).click();
      // Approximate number of years you want to reach the goal in
      cy.get("mat-select[formControlName=approxYear]")
        .click()
        .get("mat-option")
        .contains("10-15")
        .click();
      // I want to pay Premium for
      cy.get("mat-select[formControlName=payPremiumFor]")
        .click()
        .get("mat-option")
        .contains("5-9")
        .click();
      // cy.get(
      //   ".savings-traditional-form :nth-child(15) > :nth-child(2) > mat-radio-group > :nth-child(1) > mat-radio-button > label"
      // ).click();
      cy.get("button.generate-quote-btn")
        .should("be.enabled")
        .click()
        .wait(10000);

      const minPt = 10;
      const maxPt = 15;
      const pptFrequency = "Monthly";
      const premium = 200000;
      const minPpt = 5;
      const maxPpt = 9;
      const risk = 2;
      // const insurer = "ETLI";
      // const insurer = "IPRU";
      // const insurer = insurer;

      cy.wrap(allProducts.rows).each((product) => {
        if (
          product.PT >= minPt &&
          product.PT <= maxPt &&
          product.PPT >= minPpt &&
          product.PPT <= maxPpt &&
          product["Risk Profile"] === risk &&
          product["PPT Frequency"] === pptFrequency &&
          product["Min premium"] <= premium
          // product["Insurer"] === insurer
        ) {
          expectedProducts.push(product);
        }
      });

      cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);

      // cy.get("button").get(".btn-div").contains("Show all").click().wait(4000);
      // cy.get("button").get(".btn-div").contains("Show all").click();

      let plans = [];

      cy.url().should("include", "quote-unit-link");
      cy.log(cy.url.split);
      cy.url().then((url) => {
        let category = url.split(`quote-unit-link/`)[1];

        cy.request(
          `https://uat.bancaedge.com/api/v1/quote/getQuote/${category}`
        ).then((response) => {
          // https://on.cypress.io/assertions
          // cy.log("RES", response);
          console.log("API RESPONSE", response);
          expectedNumQuotes = response.body.numQuotesExpected;
          // The value 60 is assiagned
          console.log("Expected Products", expectedProducts);
          // Expected Product Array contains XLSX Filtered EElements
          // console.log("Expected Quotes in API", expectedNumQuotes);
          // Expected NumberofQuotes is value Received from API : Total Num of Quote
          Objquote = response.body.productQuote;
          console.log("Expected Product Quotes in API", Objquote);

          Objquote.forEach((quote) => {
            console.log("OBJ API Each Quote", quote);
            // cy.log(name);
            const obj = {
              planName: quote.productName,
              pt: quote.pt,
              ppt: quote.ppt,
            };
            plans.push(obj);
          });
          console.log("Printing Plans Array", plans);
          // cy.writeFile("products.txt", plans);
          expectedProducts.forEach((plan) => {
            console.log(
              "PRINT Expected Individual PLAN =======================",
              plan
            );

            const planIndex = plans.findIndex((eachPlan) => {
              // console.log(
              //   "PRINT EACH PLAN 58 =======================",
              //   eachPlan
              // );

              return (
                plan["Product Name"] === eachPlan.planName.trim() &&
                plan["PT"] === eachPlan.pt &&
                plan["PPT"] === eachPlan.ppt
              );
            });
            if (planIndex === -1) {
              plansNotFound.push(plan);
            }
          });
          plansNotFound.forEach((plan) => {
            console.log("not found plans", plan);
          });
        });
      });
      cy.wait(8000);
      // expect(expectedNumQuotes).equal(expectedProducts.length);
      cy.wrap(plansNotFound)
        .each((plan) => {
          cy.log(
            `**Expecting ${plan["Product Name"]} with pt ${plan.PT} and ppt ${plan.PPT} to be Found**`
          );
        })
        .wait(1000)
        .then(() => {
          expect(Objquote).to.have.length(expectedProducts.length);
        });

      cy.writeFile("cypress/fixtures/plansNotFound.json", plansNotFound);
    });
  });
});
